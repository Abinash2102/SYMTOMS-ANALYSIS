<!DOCTYPE html>
<html>
<head>
</head>
<body>
	<?php
		$_SESSION["email"]="";
		$_SESSION["password"]="";
		      header("location:../index.html");
	 ?>
</body>
</html>
