<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="home.css" />
</head>
<body>
    
<section>
        <div class="rt-container">
            <div class="col-rt-12">
                <div class="Scriptcontent">
                    <nav>
                        <div id="logo">VIT Hospital</div>
                        <label for="drop" class="toggle">Menu</label>
                        <input type="checkbox" id="drop" />
                        <ul class="menu">
                            <li><a href="#">Home</a></li>
                            <li><a href="contact.html">Contact</a></li>                                 
                            <li>
                                <label for="drop-2" class="toggle">Services +</label>
                                <a href="#">Services +</a>
                                <input type="checkbox" id="drop-2" />
                                <ul>
                                    <li><a href="appoinment.php">My Appoinment</a></li>
                                    <li><a href="customer.php">Customer Details</a></li>
                                </ul>
                            </li>
                            <div class="log">
                                <li><a href="logout.php">Log Out</a></li>
                            </div>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </section><br>

</body>
</html>