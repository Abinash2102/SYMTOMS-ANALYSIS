<!DOCTYPE html>
<html>
<head>
</head>
<body>
	<?php
		$_SESSION["email"]="";
		$_SESSION["password"]="";
		$_SESSION['userstatus']="";
		      header("location:../index.html");
	 ?>
</body>
</html>
